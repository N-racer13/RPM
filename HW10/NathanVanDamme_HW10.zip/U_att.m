function Uatt = U_att(q, qG)
    zeta = 0.005;
    Uatt = zeta*(q - qG);
end
